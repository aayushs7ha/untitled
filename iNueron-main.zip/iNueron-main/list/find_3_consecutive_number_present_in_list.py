def consecutive_num(input_list):
    