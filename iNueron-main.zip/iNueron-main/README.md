# iNueron
iNueron


#file_mover is the program which will move *assignment*.docx file from source to destination and then will group files into different diretory & then read content & move it to complete_file and then delete all the source files .
